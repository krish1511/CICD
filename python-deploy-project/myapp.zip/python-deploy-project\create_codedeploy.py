import boto3

# Initialize a session using AWS CodeDeploy
codedeploy = boto3.client('codedeploy')

# Define deployment details
application_name = 'YourApplicationName'
deployment_group = 'YourDeploymentGroup'
revision_location = {
    'bucket': 'your-bucket-name',
    'key': 'your-object-key'
}

# Start deployment
response = codedeploy.create_deployment(
    applicationName=application_name,
    deploymentGroupName=deployment_group,
    revision=revision_location,
    deploymentConfigName='CodeDeployDefault.OneAtATime'  # Example deployment config
)

# Print the deployment ID
print("Deployment initiated. Deployment ID:", response['deploymentId'])
